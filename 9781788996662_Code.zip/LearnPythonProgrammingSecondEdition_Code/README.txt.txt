Learn Python Programming - Second Edition

All chapters have code files.