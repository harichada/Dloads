# Mergesort Section

In order to run the tests just make sure you are in this folder
and then run:

```
$ pytest -vv -x tests
```

You can test the performances by running the `performance.py`
module in the parent folder with the following command:

```
$ python performance.py
```
