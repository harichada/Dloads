# Sudoku Section

In order to run the tests just make sure you are in this folder
and then run:

```
$ pytest -vv -x tests
```

If you want to see how the solver can be run using multi processing
you can checkout `process_solver.py`.  To run it:

```
$ python process_solver.py
```