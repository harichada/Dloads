Chapter 2 data files
====================

The files in this folder are not supposed to work if run.
They serve as source for the book chapters, and to provide a
quick copy/paste tool for whoever would need their content.
